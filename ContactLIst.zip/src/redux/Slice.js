import { createSlice } from "@reduxjs/toolkit";


const slice = createSlice({
    name: 'contactlist',
    initialState: {
        value: [] 
    },
    reducers: {
        Contactlist: (state, action) => {
            state.value.push(action.payload); 
        },
        contactdetails:(state,action)=>{
        state.value = action.payload
        },
        deleteContact: (state, action) => {
            var id = action.payload
            alert(action.payload)
            state.value = state.value.filter((obj)=>obj.data.id !== id)
        },
        Updatecontact:(state,action)=>
        {
            state.value = action.payload
        }
        
    }
});
export const {Contactlist,deleteContact,Updatecontact} = slice.actions
export default slice.reducer