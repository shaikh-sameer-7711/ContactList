import { configureStore } from "@reduxjs/toolkit";
import Contactreducer from "./Slice";
import contactDreducer from "./Slice";
import UpdateReducer from "./Slice";
const Store = configureStore({
    reducer:{
        contactlist:Contactreducer,
        contactDetails:contactDreducer,
        UpdateContact:UpdateReducer,
    }
})
export default Store;