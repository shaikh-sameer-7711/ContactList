

import { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Updatecontact } from "../redux/Slice";
import { useNavigate } from "react-router-dom";

export default function Editcontact() {
   
    const Navigate = useNavigate();
    const Dispatch = useDispatch();
    const name = useRef();
    const email = useRef();
    const mobile = useRef();

    const Update = (event) => {
        event.preventDefault();
        const uname = name.current.value;
        const uemail = email.current.value;
        const umobile = mobile.current.value;

        const obj = { name: uname, email: uemail, mobile: umobile };
        Dispatch(Updatecontact(obj));
        console.log("response is", obj);
        clearfeilddata();
    };

    const clearfeilddata = () => {
        name.current.value = '';
        email.current.value = '';
        mobile.current.value = '';
    };

    return (
        <div className="container">
            <form onSubmit={Update}>
                <h1>Edit contact</h1>
                <div className="row">
                    <div className="col-xl-4 col-md-4">
                        <label>Name</label>
                        <input type="text" placeholder="Enter Name" className="form-control" ref={name} required />
                    </div>
                </div>
                <div className="row">
                    <div className="col-xl-4 col-md-4">
                        <label>Email</label>
                        <input type="email" placeholder="Enter email" className="form-control" ref={email} required />
                    </div>
                </div>
                <div className="row">
                    <div className="col-xl-4 col-md-4">
                        <label>Mobile</label>
                        <input type="number" placeholder="Enter mobile" className="form-control" ref={mobile} required />
                    </div>
                </div>
                <button className="btn btn-success mt-4">Update</button>
                <button className="btn btn-warning mt-4" onClick={() => Navigate("/")}>Updated List</button>
            </form>
        </div>
    );
}
