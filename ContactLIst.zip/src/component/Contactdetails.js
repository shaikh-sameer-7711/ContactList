import { useSelector } from "react-redux"

export default function Contactdetails()
{
    const clist = useSelector(state=>state.contactlist.value)
    return<div className="container">
        <h1>Contact Details</h1>
     {clist.map((data)=>{
        return<div>
            <b>Name:{data.name}</b><br/>
            <b>Email:{data.email}</b><br/>
            <b>Address:{data.address}</b><br/>
            <b>Mobile:{data.mobile}</b><br/>
            </div>
     })}
       </div>
}