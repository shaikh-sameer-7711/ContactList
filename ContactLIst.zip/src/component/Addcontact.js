import { useRef } from "react"
import { useDispatch } from "react-redux";
import { ContactList, Contactlist } from "../redux/Slice";
import { useNavigate } from "react-router-dom";


export default function Addcontact()
{
    const name = useRef();
    const email = useRef();
    const mobile = useRef();
    const address = useRef();
    const dispatch = useDispatch();
    const Navigate = useNavigate();
    const Addcon=(event)=>{
        event.preventDefault()
        const cname = name.current.value;
        const cemail = email.current.value;
        const cphone = mobile.current.value;
        const caddress = address.current.value;

        const obj = {name:cname,email:cemail,mobile:cphone,address:caddress}
        console.log("response is",obj)
        dispatch(Contactlist(obj))
        Navigate('/')
    }
    return<div className="container">
        <h1 style={{textDecoration:'underline',fontFamily:'sans-serif'}}>Add Contacts</h1>
        <form onSubmit={Addcon}>
        <div className="row mt-5">
            <div className="col-xl-6 col-md-6">
            <label className="form-group">Name:</label>
            <input type="text" placeholder="Enter Your Name" className="form-control" ref={name} required/>
            </div>
        </div>
        <div className="row">
            <div className="col-xl-6 col-md-6">
            <label className="form-group">Email:</label>
            <input type="email" placeholder="Enter Your Email" className="form-control" ref={email} required/>
            </div>
        </div>
        <div className="row">
            <div className="col-xl-6 col-md-6">
            <label className="form-group">PhoneNumber:</label>
            <input type="number" placeholder="Enter Your PhoneNumber" className="form-control" ref={mobile} required/>
            </div>
        </div>
        <div className="row">
            <div className="col-xl-6 col-md-6">
            <label className="form-group">Address:</label>
            <input type="text" placeholder="Enter Your Address" className="form-control" ref={address} required/>
            </div>
        </div>
        <button className="btn btn-primary mt-4" type="submit">Submit</button>&nbsp;&nbsp;
        <button className="btn btn-secondary mt-4">Reset</button>&nbsp;&nbsp;
       </form>
       {/* <button className="btn btn-success mt-4" onClick={()=>Navigate("/")}>View List</button> */}
    </div>
}
