
import { FaCirclePlus } from "react-icons/fa6";
import { IoPersonCircleOutline } from "react-icons/io5";
import { TiEye } from "react-icons/ti";
import { MdEdit } from "react-icons/md";
import { AiFillDelete } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteContact } from "../redux/Slice";


export default function Allcontact() {
    const listdata = [   
        {
            "id": 1,
            "name": "Aaron",
            "mobile": "5785664545",
            "email": "aaron@gmail.com"
        },
        {
            "id": 2,
            "name": "Buincy Hanson",
            "mobile": "5785664545",
            "email": "hanson@gmail.com"
        }
    ]
    


    const dispatch = useDispatch()
    const Navigate = useNavigate();
    const updatec = useSelector(state => state.UpdateContact.value);
    const cdata = useSelector(state => state.contactlist.value);
    console.log("cdata", cdata);

    return<div className="main-div" style={{ width: '500px', height: '600px', backgroundColor: 'black', borderRadius: '8px', marginBlock: '8px', marginInline: '10px' }}>
            <div div className="sec-div">
                <p className="bg-primary text-white" style={{ marginBlock: '10px', marginInline: '15px', borderRadius: '5px', textAlign: 'center', padding: '8px', fontFamily: 'revert-layer' }}>All Contact&nbsp;&nbsp;<FaCirclePlus style={{ cursor: 'pointer' }} onClick={() => Navigate("/Addcontact")} /></p>
                <input type="text" placeholder="Search Contact" style={{ borderRadius: '8px', padding: '10px', marginLeft: '9rem' }} />
               

                <ol className="bg-white" style={{ width: '90%', borderRadius: '8px', marginLeft: '20px', marginTop: '10px' }}>
                    {listdata.map((data,index)=>
                        <li key={index} style={{ borderBottom: '1px solid #ccc', padding: '10px 0', display: 'flex', alignItems: 'center' }}>
                           {index+1} <IoPersonCircleOutline style={{ width: '50px', height: '50px', marginLeft: '25px' }} />
                            <div style={{ display: 'flex', padding: '5px', flexGrow: '1', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div>
                                    {data.name}<br />
                                    {data.mobile}
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <TiEye style={{ marginRight: '10px', width: "25px", height: '25px', cursor: 'pointer'}} onClick={()=>Navigate("/Contactdetails")} />
                                    <AiFillDelete style={{ marginRight: '10px', width: "25px", height: '25px', cursor: 'pointer'}} />
                                    <MdEdit style={{ width: "25px", height: '25px', cursor: 'pointer'}} />
                                </div>
                            </div>
                        </li>
                    )}
                     {cdata.map((data)=>
                        <li style={{ borderBottom: '1px solid #ccc', padding: '10px 0', display: 'flex', alignItems: 'center' }}>
                            <IoPersonCircleOutline style={{ width: '50px', height: '50px', marginLeft: '25px' }} />
                            <div style={{ display: 'flex', padding: '5px', flexGrow: '1', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div>
                                    {data.name}<br />
                                    {data.mobile}
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <TiEye style={{ marginRight: '10px', width: "25px", height: '25px', cursor: 'pointer'}} onClick={()=>Navigate("/Contactdetails")} />
                                    <AiFillDelete style={{ marginRight: '10px', width: "25px", height: '25px', cursor: 'pointer'}} onClick={()=>dispatch(deleteContact(data.id))}/>
                                    <MdEdit style={{ width: "25px", height: '25px', cursor: 'pointer'}} onClick={() =>Navigate("/Editcontact")} />
                                </div>
                            </div>
                        </li>
                    )}
            </ol>
            </div>
            </div>
        }

