import { Route, Routes } from "react-router-dom";
import Allcontact from "./component/Allcontact";
import Addcontact from "./component/Addcontact";
import Contactdetails from "./component/Contactdetails";

import EditContact from "./component/Editcontact";


export default function App()
{
  return<div>
    <Routes>
      <Route path="/" element={<Allcontact/>}></Route>
      <Route path="/Addcontact" element={<Addcontact/>}></Route>
      <Route path="/Contactdetails" element={<Contactdetails/>}></Route>
      <Route path="/Editcontact" element={<EditContact/>}></Route>
    </Routes>
  </div>
}